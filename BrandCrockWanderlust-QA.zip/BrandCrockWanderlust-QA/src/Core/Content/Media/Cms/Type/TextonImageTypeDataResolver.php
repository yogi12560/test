<?php declare(strict_types=1);

/**
 * Image resolver for the text-on-image cms element.
 *
 * Copyright (C) BrandCrock GmbH. All rights reserved.
 *
 * If you have found this script useful, a small
 * recommendation as well as a comment on our
 * home page(https://brandcrock.com/)
 * would be greatly appreciated.
 *
 * @author  BrandCrock GmbH
 * @package BrandCrockWanderlust
 * @support support@brandcrock.com
 *
 * License proprietary.
 */

namespace Bc\BrandCrockWanderlust\Core\Content\Media\Cms\Type;

use Shopware\Core\Content\Media\Cms\ImageCmsElementResolver;

// Necessary to receive image url for text-on-image element on the twig template
class TextonImageTypeDataResolver extends ImageCmsElementResolver
{
    public function getType(): string
    {
        return 'text-on-image';
    }
}
