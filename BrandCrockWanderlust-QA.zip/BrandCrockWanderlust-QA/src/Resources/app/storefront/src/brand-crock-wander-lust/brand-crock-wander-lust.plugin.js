import Plugin from 'src/plugin-system/plugin.class';
import HttpClient from 'src/service/http-client.service';

export default class BrandCrockWanderlust extends Plugin {
   
    init() {
        const that = this;
        that._client = new HttpClient(window.accessKey, window.contextToken);
		
        let productPopupInterval = false;
        let disableBcWlPopup = false;
        let disableBcWlPromotionPopup = false;
        let httpCallSuccess = false;  

        $(document).ready(function () {
            $('#preloader').css('display','none');

            $('.btn-detail-view').click(function () {
                $(this).closest('.product-info').children('.bc-wl-view-more').addClass('product-overlay-show');
            });

            $('.product-overlay-close').click(function () {
                $(this).parent().removeClass('product-overlay-show');
            });

            $('.bc-wl-slider').hide();

            $('.bc-promotion-list').each(function () {
                $('.bc-wl-slider:first', this).show();
            });
            
            that._client.get(`${window.router['wanderlust.get.wlsession']}`, (response) => {                        
                const res = JSON.parse(response);
                httpCallSuccess = true;
                if(res.disableBcWlPopup == 1) {
                    disableBcWlPopup = true;
                }
                
                if(res.disableBcWlPromotionPopup == 1) {
                    disableBcWlPromotionPopup = true;
                }
                
                if (hasClass(document.body, 'is-act-home') && disableBcWlPromotionPopup == false) {
                    $('.product_promotion_block').each(function () {
                        $('.product_promotion_popup:first', this).show();
                    });
                    productPopupInterval = setInterval(function () {
                        let active = 1;
                        const current = $('div.product_promotion_popup:visible').data('popupid');
						
                        if (current < 4) {
                            active = parseInt(current) + 1;
                        }
                        $('.product_promotion_popup[data-popupid="' + current + '"]').removeClass('fade-in');
                        $('.product_promotion_popup[data-popupid="' + current + '"]').addClass('popup_none');
                        $('.product_promotion_popup[data-popupid="' + active + '"]').addClass('fade-in');
                        $('.product_promotion_popup[data-popupid="' + active + '"]').removeClass('popup_none');
                    }, 10000);
                }
                
            });
			
            setInterval(function () {
                let active = 1;
                const current = $('li.bc-wl-slider:visible').data('slideritem');
                if (current < 5) {
                    active = parseInt(current) + 1;
                }
                $('.bc-wl-slider[data-slideritem="' + current + '"]').removeClass('fade-in');
                $('.bc-wl-slider[data-slideritem="' + current + '"]').addClass('fade-out');
                $('.bc-wl-slider[data-slideritem="' + active + '"]').addClass('fade-in');
                $('.bc-wl-slider[data-slideritem="' + active + '"]').removeClass('fade-out');
            }, 4000);
            
            if(hasClass(document.body, 'is-act-home')) {
                if($('.cms-section.pos-0').length && ( $('.cms-section.pos-0').find('.cms-block-image-cover').length || $('.cms-section.pos-0').find('.cms-block-text-on-image-banner').length )) {
                    $('header').css({
                        'position' : 'absolute',
                        'background' : 'transparent'
                    });
                } else {
                    $('header').css({
                        'position' : 'relative'
                    });
                }
                
                $('.cms-section').each(function() {
                    if( ( $(this).find('.cms-block-text-on-image-banner').length || $(this).find('.cms-block-image-cover').length || $(this).find('.cms-block-image-text-cover').length ) && !$(this).hasClass('pos-0')) {
                        $(this).css({ 'padding' : '40px 20px 40px 20px'});
                    }					
                });
            }

            var maxLength = 150;
            $('.product-desc').each(function(){
                var myStr = $(this).text();
                if($.trim(myStr).length > maxLength){
                    var newStr = myStr.substring(0, maxLength);
                    var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
                    $(this).empty().html(newStr);
                    $(this).append(' <a href="javascript:void(0);" class="read-more">'+ $('#readMoreTitle').val()+'</a>');
                    $(this).append('<span class="more-info">' + removedStr + '</span>');
                }
            });
            
            $('.read-more').click(function(){
                $(this).siblings('.more-info').contents().unwrap();
                $(this).remove();
            });
			
        });

        let menu_id = '';
        $('.main-navigation-link').hover(
            function () {
                menu_id = $(this).attr('data-flyout-menu-trigger');
                if (menu_id != undefined) {
                    $('.navigation-flyout[data-flyout-menu-id="' + menu_id + '"]').addClass('show_sub_menu');
                }
            },

            function () {
                if (menu_id != undefined) {
                    $('.navigation-flyout[data-flyout-menu-id="' + menu_id + '"]').removeClass('show_sub_menu');
                }
            });

        $('.product-box .card-body').mouseleave(function () {
            $('.bc-wl-view-more').removeClass('product-overlay-show');
        });

        $('.close-button').on('click', function () {
            that._client.get(`${window.router['wanderlust.set.popup']}?type=revealpopup`, (response) => {
                return response;
            });
            $('#reveal_popup').modal('hide');
        });

        $('.popup_close_btn').on('click', function () {
            that._client.get(`${window.router['wanderlust.set.promotionpopup']}?type=promotionpopup`, (response) => {
                return response;
            });
            $('.product_promotion_popup').addClass('popup_none');
            $('.product_promotion_popup').removeClass('fade-in');
            clearInterval(productPopupInterval);
            productPopupInterval = false;
        });

        let isOpened = false;
        const isRevealEnabled = $('#isReveal').val();
        window.addEventListener('scroll', function () {
            let docu_height = '';
            let win_scroll = '';

            if (window.innerHeight != undefined) {
                docu_height = window.innerHeight;
            }
            else {
                const docu_body = document.body;
                const docu_ele = document.documentElement;
                docu_height = Math.max(docu_ele.clientHeight, docu_body.clientHeight);
            }

            if (window.scrollY != undefined) {
                win_scroll = window.scrollY;
            } else {
                win_scroll = document.documentElement.scrollTop;
            }
            if ( hasClass(document.body, 'is-act-home') && disableBcWlPopup == false && httpCallSuccess == true ) {	
                if (win_scroll > docu_height / 3 && !isOpened) {
                    isOpened = true;
                    if(isRevealEnabled == 1) {	
                        $('#reveal_popup').modal('show');
                    }
                }
            }

            const fixed_nav = $('#fixed_nav').val();
			
            if (win_scroll >= 400 && fixed_nav != undefined && fixed_nav == 1) {
                $('.bc-wl-navigation').addClass('stickynav');
            } else {
                $('.bc-wl-navigation').removeClass('stickynav');
            }
        });

        function hasClass(element, cls) {
            return element.classList.contains(cls);
        }

        // Select image on hover
        $('.gallery-slider-thumbnails-item-inner').mouseover(function () {
            $(this).click();
        });

        $('#bc_wl_custom_slide').click(function () {
            $('.bc_wl_listing_side_bar').addClass('bc_modal_is_open');
            $('.bc_wl_backdrop').addClass('show');
            $('body').css('overflow', 'hidden');
        });

        $('#bc_wl_slide_close').click(function () {
            $('.bc_wl_listing_side_bar').removeClass('bc_modal_is_open');
            $('.bc_wl_backdrop').removeClass('show');
            $('body').css('overflow', 'auto');
        });

        $('.bc_wl_backdrop').click(function (e) {
            if (!$(e.target).closest('.bc_modal_is_left').length) {
                $('.bc_wl_custom_slider').hide();
                $('.bc_wl_backdrop').removeClass('show');
                $('body').css('overflow', 'auto');
            }
        });

        $('#bc_wl_horizontal_btn').click(function () {
            $('.bc_wl_horizontal_filter').show();
        });

        if(document.getElementById('bc_wl_horizontal_btn')) {
            document.getElementById('bc_wl_horizontal_btn').addEventListener('click', function () {
                if ($('#bc_wl_horizontal_filter').css('visibility') === 'hidden') {
                    $('#bc_wl_horizontal_filter').addClass('bc_wl_hori_filter_show');
                } else if ($('#bc_wl_horizontal_filter').css('visibility') === 'visible') {
                    $('#bc_wl_horizontal_filter').removeClass('bc_wl_hori_filter_show');
                }
            });
        }
		
    }
}
