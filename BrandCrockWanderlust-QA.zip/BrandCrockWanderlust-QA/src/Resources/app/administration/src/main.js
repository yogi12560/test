import './module/sw-cms/elements/text-on-image';
import './module/sw-cms/blocks/text-image/text-on-image-three-column';
import './module/sw-cms/blocks/text-image/text-on-image-two-column';
import './module/sw-cms/blocks/text-image/text-on-image-banner';

import enGB from './module/sw-cms/snippet/en-GB.json';
import deDE from './module/sw-cms/snippet/de-DE.json';

Shopware.Locale.extend('en-GB', enGB);
Shopware.Locale.extend('de-DE', deDE);