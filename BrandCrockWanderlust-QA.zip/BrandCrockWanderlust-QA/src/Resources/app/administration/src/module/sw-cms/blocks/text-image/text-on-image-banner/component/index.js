import template from './sw-cms-block-text-on-image-banner.html.twig';
import './sw-cms-block-text-on-image-banner.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-text-on-image-banner', {
    template
});