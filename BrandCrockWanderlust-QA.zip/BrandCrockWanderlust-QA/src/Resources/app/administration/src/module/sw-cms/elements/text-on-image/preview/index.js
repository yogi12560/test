import template from './sw-cms-el-preview-text-on-image.html.twig';
import './sw-cms-el-preview-text-on-image.scss';

Shopware.Component.register('sw-cms-el-preview-text-on-image', {
    template
});