import template from './sw-cms-block-text-on-image-three-column.html.twig';
import './sw-cms-block-text-on-image-three-column.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-text-on-image-three-column', {
    template
});