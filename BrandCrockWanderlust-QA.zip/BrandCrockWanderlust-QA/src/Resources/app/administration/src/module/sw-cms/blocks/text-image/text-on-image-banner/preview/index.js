import template from './sw-cms-preview-text-on-image-banner.html.twig';
import './sw-cms-preview-text-on-image-banner.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-text-on-image-banner', {
    template
});