import template from './sw-cms-preview-text-on-image-two-column.html.twig';
import './sw-cms-preview-text-on-image-two-column.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-text-on-image-two-column', {
    template
});