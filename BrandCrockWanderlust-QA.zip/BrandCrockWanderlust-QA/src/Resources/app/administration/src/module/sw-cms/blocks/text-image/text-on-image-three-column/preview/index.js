import template from './sw-cms-preview-text-on-image-three-column.html.twig';
import './sw-cms-preview-text-on-image-three-column.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-text-on-image-three-column', {
    template
});