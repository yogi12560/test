import './component';
import './preview';

Shopware.Service('cmsService').registerCmsBlock({
    name: 'text-on-image-two-column',
    label: 'sw-cms.blocks.imageText.textOnImageTwoColumn.label',
    category: 'text-image',
    component: 'sw-cms-block-text-on-image-two-column',
    previewComponent: 'sw-cms-preview-text-on-image-two-column',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '20px',
        marginRight: '20px',
        sizingMode: 'boxed'
    },
    slots: {
        'left': {
            type: 'text-on-image',
            default: {
                config: {
                    verticalAlign: { source: 'static', value: 'center' },
                    displayMode: { source: 'static', value: 'cover' },
                    content: {
                        source: 'static',
                        value: `
                        <h2 style="text-align: center; color: #FFFFFF">Lorem Ipsum dolor</h2>
                        <p style="text-align: center; color: #FFFFFF">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                        sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                        `.trim()
                    }
                },
                data: {
                    media: {
                        url: '/administration/static/img/cms/preview_camera_large.jpg'
                    }
                }
            }
        },
        'right': {
            type: 'text-on-image',
            default: {
                config: {
                    verticalAlign: { source: 'static', value: 'center' },
                    displayMode: { source: 'static', value: 'cover' },
                    content: {
                        source: 'static',
                        value: `
                        <h2 style="text-align: center; color: #FFFFFF">Lorem Ipsum dolor</h2>
                        <p style="text-align: center; color: #FFFFFF">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                        sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                        `.trim()
                    }
                },
                data: {
                    media: {
                        url: '/administration/static/img/cms/preview_plant_large.jpg'
                    }
                }
            }
        }
    }
});
