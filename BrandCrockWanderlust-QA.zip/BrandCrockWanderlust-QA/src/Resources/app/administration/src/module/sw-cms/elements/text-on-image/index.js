import './preview';
import './config';
import './component';

Shopware.Service('cmsService').registerCmsElement({
    name: 'text-on-image',
    label: 'sw-cms.elements.textOnImage.label',
    component: 'sw-cms-el-text-on-image',
    configComponent: 'sw-cms-el-config-text-on-image',
    previewComponent: 'sw-cms-el-preview-text-on-image',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'media'
            }
        },
        displayMode: {
            source: 'static',
            value: 'cover'
        },
        url: {
            source: 'static',
            value: null
        },
        newTab: {
            source: 'static',
            value: false
        },
        minHeight: {
            source: 'static',
            value: '340px'
        },
        content: {
            source: 'static',
            value: `
                <h2>Lorem Ipsum dolor sit amet</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. </p>
            `.trim()
        },
        verticalAlign: {
            source: 'static',
            value: 'center'
        },
        padding: {
            source: 'static',
            value:'15'
        }
    }
});