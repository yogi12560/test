import template from './sw-cms-el-text-on-image.html.twig';
import './sw-cms-el-text-on-image.scss';

const { Component, Mixin } = Shopware;

Component.register('sw-cms-el-text-on-image', {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],
    data() {
        return {
            editable: true,
            demoValue: ''
        };
    },

    computed: {
        displayModeClass() {
            if (this.element.config.displayMode.value === 'standard') {
                return null;
            }

            return `is--${this.element.config.displayMode.value}`;
        },

        styles() {
            return {
                'min-height': this.element.config.displayMode.value === 'cover' &&
                this.element.config.minHeight.value !== 0 ? this.element.config.minHeight.value : '340px',
                'align-self': !this.element.config.verticalAlign.value ? null : this.element.config.verticalAlign.value,
            };
        },

        textPadding() {
            return {
                'padding': this.element.config.padding.value ? this.element.config.padding.value + 'px' : '15px'
            }
        },

        mediaUrl() {
            const context = Shopware.Context.api;
            const elemData = this.element.data.media;
            const mediaSource = this.element.config.media.source;

            if (mediaSource === 'mapped') {
                const demoMedia = this.getDemoValue(this.element.config.media.value);

                if (demoMedia && demoMedia.url) {
                    return demoMedia.url;
                }
            }

            if (elemData && elemData.id) {
                return this.element.data.media.url;
            }

            if (elemData && elemData.url) {
                return `${context.assetsPath}${elemData.url}`;
            }

            return `${context.assetsPath}/administration/static/img/cms/preview_mountain_large.jpg`;
        }
    },

    watch: {
        cmsPageState: {
            deep: true,
            handler() {
                this.$forceUpdate();
                this.updateDemoValue();
            }
        },
        'element.config.content.source': {
            handler() {
                this.updateDemoValue();
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('text-on-image');
            this.initElementData('text-on-image');
        },
        updateDemoValue() {
            if (this.element.config.content.source === 'mapped') {
                this.demoValue = this.getDemoValue(this.element.config.content.value);
            }
        },

        onBlur(content) {
            this.emitChanges(content);
        },

        onInput(content) {
            this.emitChanges(content);
        },

        emitChanges(content) {
            if (content !== this.element.config.content.value) {
                this.element.config.content.value = content;
                this.$emit('element-update', this.element);
            }
        }
    }
});