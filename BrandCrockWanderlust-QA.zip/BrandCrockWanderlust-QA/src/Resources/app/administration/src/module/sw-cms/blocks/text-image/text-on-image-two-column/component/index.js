import template from './sw-cms-block-text-on-image-two-column.html.twig';
import './sw-cms-block-text-on-image-two-column.scss';

const { Component } = Shopware;

Component.register('sw-cms-block-text-on-image-two-column', {
    template
});