<?php declare(strict_types = 1);

/**
 * To Install Wanderlust theme and its Shopping experience elements for the layout design.
 *
 * Copyright (C) BrandCrock GmbH. All rights reserved.
 *
 * If you have found this script useful, a small
 * recommendation as well as a comment on our
 * home page(https://brandcrock.com/)
 * would be greatly appreciated.
 *
 * @author  BrandCrock GmbH
 * @package BrandCrockWanderlust
 * @support support@brandcrock.com
 *
 * License proprietary.
 */

namespace Bc\BrandCrockWanderlust;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Shopware\Core\Framework\Uuid\Uuid;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\FetchMode;
use Shopware\Core\Defaults;
use Shopware\Core\Content\Media\File\FileSaver;
use Shopware\Core\Content\Media\File\MediaFile;
use Shopware\Core\Framework\Context;
use Symfony\Component\Config\FileLocator;

class BrandCrockWanderlust extends Plugin implements ThemeInterface
{
    private $connection;
    private $fileSaver;
    private $context;

    // Default media folders
    private $bc_default_folder_name = [
        ['id' => '2a6ec27b55704a43b1f0966379abc070'],
        ['id' => '7c6250cd229e41bfa73993b11fd8dedc'],
        ['id' => '8faa3d0c8a204149a58ef2613be952b5'],
        ['id' => '68bb9e84e0c04bfaabe296eb07f48d9f'],
        ['id' => '40632390b63f40a798b27fb52f1653e6'],
        ['id' => 'b0c0d82d60904f69aa5204babbb1af66'],
        ['id' => 'c08e710f96f242598267b67e02adcd40'],
    ];

    // Demo media file names
    private $bc_media_files_ary = [
        'bc_wl_main_banner',
        'bc_wl_category1',
        'bc_wl_category2',
        'bc_wl_category3',
        'bc_wl_side_banner1',
        'bc_wl_promotion_banner',
        'bc_wl_side_banner2'
    ];

    // Theme media file names
    private $bc_theme_media_files_ary = [
        'bc_wl_logo',
        'bc_wl_icon',
        'bc_wl_favicon',
        'bc_wl_app_store',
        'bc_wl_google_play',
        'bc_wl_preview',
        'bc_wl_promotion_img1',
        'bc_wl_promotion_img2',
        'bc_wl_promotion_img3',
        'bc_wl_promotion_img4',
        'bc_wl_spinner',
        'bc_wl_order_now'
    ];

    // BC media folder path
    private $mPath = __DIR__ . '/Resources/media/';

    public function getThemeConfigPath(): string
    {
        return 'theme.json';
    }

    public function build(ContainerBuilder $container): void
    {
        parent::build($container);
    }
	
	    
    /**
     * Install the theme plugin and create the cms page
     * @param InstallContext $installContext
     * return void
     */
	
    public function install(InstallContext $installContext): void
    {
        $this->connection = $this->container->get(Connection::class);
        $this->fileSaver = $this->container->get(FileSaver::class);
        $this->context = Context::createDefaultContext();
		$bcCmsPageId = $this->getBcCmsPageId($this->connection);
        if ($bcCmsPageId === null) {
            $this->createBcCmsPage($this->connection);
        } else {
			return;
		}
        
    }

    /**
     * Create CMS page entries and configuration
     * @param Connection $connection
     */
    private function createBcCmsPage(Connection $connection): void
    {
        $languageEn = Uuid::fromHexToBytes(Defaults::LANGUAGE_SYSTEM);
        $languageDe = $this->getLanguageDeId($this->connection);
        $versionId = Uuid::fromHexToBytes(Defaults::LIVE_VERSION);
        $cmsFolder = $this->getDefaultFolderIdForEntity('cms_page');

        // Create dynamic media folders
        $bcMediaFiles = [
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomHex(),
                'media_folder_id' => Uuid::fromHexToBytes($cmsFolder),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
        ];

        $result = 0;

        // Insert theme media files into the media table
        foreach ($bcMediaFiles as $bKey => $bcMediaFile) {
            rename($this->mPath . $this->bc_default_folder_name[$bKey]['id'],
                $this->mPath . $bcMediaFiles[$bKey]['id']);
            $bcMediaFile['id'] = Uuid::fromHexToBytes($bcMediaFile['id']);
            $result = $this->connection->insert('media', $bcMediaFile);
        }

        // Map media folder images to the inserted media entries
        if ($result) {
            foreach (glob(__DIR__ . '/Resources/media/*/*.jpg') as $file) {
                $this->fileSaver->persistFileToMedia(
                    new MediaFile(
                        $file,
                        mime_content_type($file),
                        pathinfo($file, PATHINFO_EXTENSION),
                        filesize($file)
                    ),
                    pathinfo($file, PATHINFO_FILENAME),
                    basename(dirname($file)),
                    $this->context
                );
            }
        }

        // Create demo CMS page
        $page = [
            'id' => Uuid::randomBytes(),
            'type' => 'landingpage',
            'locked' => 0,
            'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ];
        $pageEn = [
            'cms_page_id' => $page['id'],
            'language_id' => $languageEn,
            'name' => 'Wanderlust Demo Home',
            'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ];
        $pageDe = [
            'cms_page_id' => $page['id'],
            'language_id' => $languageDe,
            'name' => 'Wanderlust Demo Home',
            'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
        ];

        $this->connection->insert('cms_page', $page); // Insert demo cms page
        $this->connection->insert('cms_page_translation', $pageEn); // Insert English version
        if ($languageDe) {
            $this->connection->insert('cms_page_translation', $pageDe); // Insert German version
        }

        // Sections for demo CMS page
        $bcSections = [
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 0,
                'type' => 'default',
                'name' => 'bc-wl-top-banner-block',
                'sizing_mode' => 'full_width',
                'css_class' => 'bc-wl-top-banner',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 1,
                'type' => 'default',
                'name' => 'bc-wl-category-heading-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-category-heading',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 2,
                'type' => 'default',
                'name' => 'bc-wl-category-list-img-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-category-list-img',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 3,
                'type' => 'default',
                'name' => 'bc-wl-promotion-slide1-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-promotion-slide1',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 4,
                'type' => 'default',
                'name' => 'bc-wl-product-slider1-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-product-slider1',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 5,
                'type' => 'default',
                'name' => 'bc-wl-company-desc-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-company-desc',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 6,
                'type' => 'default',
                'name' => 'bc-wl-promotion-banner-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-promotion-banner',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 7,
                'type' => 'default',
                'name' => 'bc-wl-product-slider2-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-product-slider2',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
            [
                'id' => Uuid::randomBytes(),
                'cms_page_id' => $page['id'],
                'position' => 8,
                'type' => 'default',
                'name' => 'bc-wl-promotion-slide2-block',
                'sizing_mode' => 'full_width',
                'background_media_mode' => 'cover',
                'css_class' => 'bc-wl-promotion-slide2',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
            ],
        ];

        // Insert the sections
        foreach ($bcSections as $bcSection) {
            $this->connection->insert('cms_section', $bcSection);
        }

        // Blocks for Demo CMS page
        $blocks = [
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[0]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'text-on-image-banner',
                'name' => 'bc-wl-top-banner-bk',
                'background_media_mode' => 'cover',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[1]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'text-teaser',
                'name' => 'bc-wl-category-heading-bk',
                'background_media_mode' => 'cover',
                'margin_top' => '20px',
                'margin_left' => '20px',
                'margin_bottom' => '20px',
                'margin_right' => '20px',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[2]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'image-text-bubble',
                'name' => 'bc-wl-category-category-img-bk',
                'background_media_mode' => 'cover',
                'margin_top' => '20px',
                'margin_left' => '20px',
                'margin_bottom' => '20px',
                'margin_right' => '20px',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[3]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'image-text-cover',
                'name' => 'bc-wl-promotion-slide1-bk',
                'background_media_mode' => 'cover'
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[4]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'product-slider',
                'name' => 'bc-wl-product-slider1-bk',
                'background_media_mode' => 'cover',
                'margin_top' => '20px',
                'margin_left' => '20px',
                'margin_bottom' => '20px',
                'margin_right' => '20px',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[5]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'text-hero',
                'name' => 'bc-wl-company-desc-bk',
                'background_media_mode' => 'cover',
                'margin_top' => '20px',
                'margin_left' => '20px',
                'margin_bottom' => '20px',
                'margin_right' => '20px',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[6]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'text-on-image-banner',
                'name' => 'bc-wl-promotion-banner-bk',
                'background_media_mode' => 'cover',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[7]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'product-slider',
                'name' => 'bc-wl-product-slider2-bk',
                'background_media_mode' => 'cover',
                'margin_top' => '20px',
                'margin_left' => '20px',
                'margin_bottom' => '20px',
                'margin_right' => '20px',
            ],
            [
                'id' => Uuid::randomBytes(),
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'cms_section_id' => $bcSections[8]['id'],
                'locked' => 0,
                'position' => 0,
                'section_position' => 'main',
                'type' => 'image-text-cover',
                'name' => 'bc-wl-promotion-slide2-bk',
                'background_media_mode' => 'cover',
            ],

        ];

		// Insert cms blocks
        foreach ($blocks as $block) {
            $this->connection->insert('cms_block', $block);
        }

        // Slots for demo CMS page
        $slots = [
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[0]['id'],
                'type' => 'text-on-image',
                'slot' => 'main',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[1]['id'],
                'type' => 'text',
                'slot' => 'content',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'image',
                'slot' => 'left-image',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'text',
                'slot' => 'left-text',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'image',
                'slot' => 'center-image',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'text',
                'slot' => 'center-text',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'image',
                'slot' => 'right-image',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[2]['id'],
                'type' => 'text',
                'slot' => 'right-text',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[3]['id'],
                'type' => 'image',
                'slot' => 'left',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[3]['id'],
                'type' => 'text',
                'slot' => 'right',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[4]['id'],
                'type' => 'product-slider',
                'slot' => 'productSlider',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[5]['id'],
                'type' => 'text',
                'slot' => 'content',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[6]['id'],
                'type' => 'text-on-image',
                'slot' => 'main',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[7]['id'],
                'type' => 'product-slider',
                'slot' => 'productSlider',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[8]['id'],
                'type' => 'image',
                'slot' => 'left',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
            [
                'id' => Uuid::randomBytes(),
                'locked' => 0,
                'cms_block_id' => $blocks[8]['id'],
                'type' => 'text',
                'slot' => 'right',
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'version_id' => $versionId
            ],
        ];

		// Get default demo product ids
        $productIds = $this->getShopProductIds(8);

        // Slot translation and configuration
        $slotTranslationData = [
            [
                'cms_slot_id' => $slots[0]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[0]['id'], 'source' => 'static'],
                    'content' => [
                        'value' => "<p style=\"text-align: center;\"><font color=\"#ffffff\">Up to 30% Discount<br><span style=\"font-size: 28px; font-weight: 600; letter-spacing: 0px;\">Fresh Grocery Collection</span></font></p>\n <p style=\"text-align: center;\"><a class=\"btn btn-primary\" href=\"https://google.com\" target=\"_blank\">Shop Now</a><br></p>",
                        'source' => 'static'
                    ],
                    'minHeight' => ['value' => '340px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => 'center', 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[1]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">100% Organic Products<br></h2>\n<p style=\"text-align: center;\"><i>Experience nature as it was meant to be<br></i></p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[2]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[1]['id'], 'source' => 'static'],
                    'minHeight' => ['value' => '340px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[3]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Fresh Veggies<br></h2>\n <p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, \n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, \n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[4]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[2]['id'], 'source' => 'static'],
                    'minHeight' => ['value' => '340px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[5]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Sparkly Fruits<br></h2>\n <p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, \n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, \n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[6]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[3]['id'], 'source' => 'static'],
                    'minHeight' => ['value' => '340px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[7]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Leafy Greens<br></h2>\n <p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, \n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, \n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[8]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[4]['id'], 'source' => 'static'],
                    'minHeight' => ['value' => '400px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[9]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Why is Organic Good for You? <br></h2>\n <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,\n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,\n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.\n Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\n Lorem ipsum dolor sit amet, consetetur sadipscing elitr,\n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\n At vero eos et accusam et justo duo dolores et ea rebum.\n Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[10]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'title' => ['source' => 'static', 'value' => 'New Arrivals'],
                    'border' => ['source' => 'static', 'value' => false],
                    'rotate' => ['value' => false, 'source' => 'static'],
                    'products' => [
                        'value' => [$productIds[0], $productIds[1], $productIds[2], $productIds[3]],
                        'source' => 'static'
                    ],
                    'boxLayout' => ['value' => 'standard', 'source' => 'static'],
                    'elMinWidth' => ['value' => '350px', 'source' => 'static'],
                    'navigation' => ['value' => true, 'source' => 'static'],
                    'displayMode' => ['value' => 'standard', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[11]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">About our company</h2>\n <hr>\n <p style=\"text-align: center;\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, \n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, \n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. \n Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[12]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[5]['id'], 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Can You Only Eat Vegetables &amp; Still Stay Healthy?</h2><div align=\"center\"><h2><br></h2></div>\n <p style=\"text-align: center;\"><a class=\"btn btn-primary\" href=\"http://www.google.com\" target=\"_self\">READ MORE</a><br></p>",
                        'source' => 'static'
                    ],
                    'minHeight' => ['value' => '550px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => 'center', 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[13]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'title' => ['source' => 'static', 'value' => 'Best Sellers'],
                    'border' => ['source' => 'static', 'value' => false],
                    'rotate' => ['value' => false, 'source' => 'static'],
                    'products' => [
                        'value' => [$productIds[3], $productIds[0], $productIds[2], $productIds[1]],
                        'source' => 'static'
                    ],
                    'boxLayout' => ['value' => 'standard', 'source' => 'static'],
                    'elMinWidth' => ['value' => '350px', 'source' => 'static'],
                    'navigation' => ['value' => true, 'source' => 'static'],
                    'displayMode' => ['value' => 'standard', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[14]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'url' => ['value' => null, 'source' => 'static'],
                    'newTab' => ['value' => false, 'source' => 'static'],
                    'media' => ['value' => $bcMediaFiles[6]['id'], 'source' => 'static'],
                    'minHeight' => ['value' => '400px', 'source' => 'static'],
                    'displayMode' => ['value' => 'cover', 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ],
            [
                'cms_slot_id' => $slots[15]['id'],
                'cms_slot_version_id' => $versionId,
                'language_id' => $languageEn,
                'created_at' => (new \DateTime())->format(Defaults::STORAGE_DATE_TIME_FORMAT),
                'config' => json_encode([
                    'color' => ['value' => null, 'source' => 'static'],
                    'content' => [
                        'value' => "<h2 style=\"text-align: center;\">Try a Shake Every Day! <br></h2>\n <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,\n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,\n sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.\n Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\n Lorem ipsum dolor sit amet, consetetur sadipscing elitr,\n sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\n At vero eos et accusam et justo duo dolores et ea rebum.\n Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>",
                        'source' => 'static'
                    ],
                    'padding' => ['value' => null, 'source' => 'static'],
                    'verticalAlign' => ['value' => null, 'source' => 'static']
                ])
            ]
        ];

		// Slot translation text array
        $slotTranslations = [];
        foreach ($slotTranslationData as $slotTranslationDatum) {
            $slotTranslations[] = $slotTranslationDatum;

            if ($languageDe) {
                $slotTranslationDatum['language_id'] = $languageDe;
                $slotTranslations[] = $slotTranslationDatum;
            }
        }

        foreach ($slots as $slot) {
            $this->connection->insert('cms_slot', $slot);
        }

        foreach ($slotTranslations as $translation) {
            $this->connection->insert('cms_slot_translation', $translation);
        }
    }

    /**
     * Get German language id
     * @param Connection $connection
     * @return string $result
     */
    private function getLanguageDeId(Connection $connection): ?string
    {
        $result = $connection->fetchColumn('
            SELECT lang.id
            FROM language lang
            INNER JOIN locale loc ON lang.translation_code_id = loc.id
            AND loc.code = "de-DE"
        ');

        if ($result === false || Uuid::fromHexToBytes(Defaults::LANGUAGE_SYSTEM) === $result) {
            return null;
        }

        return (string)$result;
    }

    /**
     * Get default media folder ids
     * @param string $entity
     * @return string $result
     */
    private function getDefaultFolderIdForEntity(string $entity)
    {
        $result = $this->connection->fetchColumn('
            SELECT LOWER(HEX(`media_folder`.`id`))
            FROM `media_default_folder`
            JOIN `media_folder` ON `media_default_folder`.`id` = `media_folder`.`default_folder_id`
            WHERE `media_default_folder`.`entity` = :entity;
        ', ['entity' => $entity]);

        if (!$result) {
            throw new \RuntimeException('No default folder for entity "' . $entity . '" found, please make sure that basic data is available by running the migrations.');
        }

        return (string)$result;
    }

    /**
     * Get product ids
     * @param int $limit
     * @return array $shopProductIds
     */
    private function getShopProductIds($limit): array
    {
        $sql = 'SELECT LOWER(HEX(id)) as id FROM product LIMIT ' . $limit;

        $shopProductIds = $this->connection->fetchAll($sql);

        return array_column($shopProductIds, 'id');
    }
    
	 /**
     * Uninstall the theme plugin and create cms page
     * @param UninstallContext $uninstallContext
     * return void
     */
    public function uninstall(UninstallContext $uninstallContext): void
    {
        $this->connection = $this->container->get(Connection::class);
        $this->removeBcCmsPage($this->connection);
        if ($uninstallContext->keepUserData()) {
            parent::uninstall($uninstallContext);

            return;
        }
        
		// Remove plugin configuration
        $this->connection->executeQuery('DELETE FROM `system_config` WHERE `configuration_key` LIKE "%BrandCrockWanderlust.config%"');        
    }

    /**
     * Remove CMS page entries and configuration
     * @param Connection $connection
     */
    private function removeBcCmsPage(Connection $connection): void
    {
        $bcCmsPageId = $this->getBcCmsPageId($connection);
        if ($bcCmsPageId === null) {
            return;
        }
        
		if($bcCmsPageId !== null && $this->isCmsPageActive($bcCmsPageId) == 1) {
			return;
		}

        $sectionId = $connection->fetchAll('
            SELECT id
            FROM cms_section
            WHERE cms_page_id = :cms_page_id
            ', ['cms_page_id' => $bcCmsPageId]
        );
        
        $blockIds = array();
        
        foreach ($sectionId as $sectionKey => $sectionValue) {
            $blockId = $connection->fetchAll('
					SELECT id
					FROM cms_block
					WHERE cms_section_id = :cms_section_id',
                ['cms_section_id' => $sectionValue['id']]
            );
            $blockIds[] = $blockId;
        }


        foreach ($blockIds as $blockVal) {
            foreach ($blockVal as $blockKey => $blockValue) {
                $slotId = $connection->fetchColumn('
					SELECT id
					FROM cms_slot
					WHERE cms_block_id = :blockId',
                    ['blockId' => $blockValue['id']]
                );
                if ($slotId !== null) {
                    $this->connection->executeQuery('DELETE FROM `cms_slot_translation` WHERE `cms_slot_id` = :slotId',
                        ['slotId' => $slotId]);
                    $this->connection->executeQuery('DELETE FROM `cms_slot` WHERE `cms_block_id` = :blockId',
                        ['blockId' => $blockValue['id']]);
                }
                $this->connection->executeQuery('DELETE FROM `cms_block`WHERE `id` = :blockId',
                    ['blockId' => $blockValue['id']]);
            }
        }

        foreach ($sectionId as $sectionKey => $sectionValue) {
            $this->connection->executeQuery('DELETE FROM `cms_section` WHERE `id` = :sectionId',
                ['sectionId' => $sectionValue['id']]);
        }

        if ($bcCmsPageId !== null) {
            $this->connection->executeQuery('DELETE FROM `cms_page_translation` WHERE `cms_page_id` = :cmsPageId',
                ['cmsPageId' => $bcCmsPageId]);
            $this->connection->executeQuery('DELETE FROM `cms_page` WHERE `id` = :pageId', ['pageId' => $bcCmsPageId]);
        }

        foreach ($this->bc_media_files_ary as $bcMediaName) {
            $this->connection->executeQuery('DELETE FROM `media` WHERE `file_name` = :fileName',
                ['fileName' => $bcMediaName]);
        }

        // Rename the default folder name to dynamically generated media folders
        foreach (glob(__DIR__ . '/Resources/media/*/*.jpg') as $file) {
            if ($this->bc_media_files_ary[0] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[0]['id']);
            }
			if ($this->bc_media_files_ary[1] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[1]['id']);
            }
			if ($this->bc_media_files_ary[2] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[2]['id']);
            }
			if ($this->bc_media_files_ary[3] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[3]['id']);
            }
			if ($this->bc_media_files_ary[4] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[4]['id']);
            }
			if ($this->bc_media_files_ary[5] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[5]['id']);
            }
			if ($this->bc_media_files_ary[6] == pathinfo($file, PATHINFO_FILENAME)) {
                rename($this->mPath . basename(dirname($file)), $this->mPath . $this->bc_default_folder_name[6]['id']);
            }
        }

        $this->connection->executeQuery('DELETE FROM `theme` WHERE `technical_name` = :themeName',
            ['themeName' => 'BrandCrockWanderlust']);

        foreach ($this->bc_theme_media_files_ary as $bcThemeMediaName) {
            $this->connection->executeQuery('DELETE FROM `media` WHERE `file_name` = :fileName',
                ['fileName' => $bcThemeMediaName]);
        }

    }

    /**
     * Get Cms page id
     * @param Connection $connection
     * @return string $result
     */
    private function getBcCmsPageId(Connection $connection): ?string
    {
        $result = $connection->fetchColumn('
            SELECT cms_page_id
            FROM cms_page_translation
            INNER JOIN cms_page ON cms_page.id = cms_page_translation.cms_page_id
            WHERE name = :name
            ', ['name' => 'Wanderlust Demo Home']
        );
        return $result === false ? null : (string)$result;
    }
    
	/**
     * Check cms page is active
     * @param $pageId string
     * return $result int
     */
    private function isCmsPageActive($pageId): ?int
    {
        $result = $this->connection->fetchColumn(
            'SELECT active
            FROM category
            WHERE cms_page_id = :cms_page_id',
            ['cms_page_id' => $pageId]
        );
        return (int) $result;
    }
}
