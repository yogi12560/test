# 1.0.0
- First version of the Wanderlust Theme for Shopware 6
