# Wanderlust - Premium Responsive Theme

A theme designed for Shopware 6 in accordance with a modern, mobile-friendly philosophy.