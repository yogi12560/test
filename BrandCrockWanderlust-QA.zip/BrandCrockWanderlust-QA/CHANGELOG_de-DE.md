# 1.0.0
- Erste Version des Wanderlust Themas für Shopware 6
