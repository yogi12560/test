import ExamplePlugin from './basic-plugin/example-plugin.plugin';
import Counter from './basic-plugin/jquery.counterup.min.plugin';
import Waypoints from './basic-plugin/waypoints.min.plugin';

const PluginManager = window.PluginManager;
PluginManager.register('ExamplePlugin', ExamplePlugin);
PluginManager.register('Counter', Counter);
PluginManager.register('Waypoints', Waypoints);


