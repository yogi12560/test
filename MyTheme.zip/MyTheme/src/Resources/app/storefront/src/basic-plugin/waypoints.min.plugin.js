import Plugin from 'src/plugin-system/plugin.class';

export default class Waypoints extends Plugin {

 init() {
 	console.log("ujgfsdui");
} }