import Plugin from 'src/plugin-system/plugin.class';

export default class ExamplePlugin extends Plugin {

	 init() {
        window.onscroll = function() {
            if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
                $("#modalCoupon").modal('show');
            }
        };

        	$(".top-bar-currency").hover(
        function(){
      		$(".top-bar-currency .dropdown-menu").show();
	               	},
		    function(){
      		$(".top-bar-currency .dropdown-menu").hide();
		    }
		    );

        $(".circleBase").parent().css({"border-radius":"30%","background-color":"#F2E6D6","margin":"15px"});
    }

 

}

	