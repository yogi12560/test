import Plugin from 'src/plugin-system/plugin.class';

export default class Counter extends Plugin {

	 init() {
 	console.log("loadin");
} }